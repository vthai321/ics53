#ifndef HELPERS_H
#define HELPERS_H
#include <stdlib.h>
#include <stdint.h>

/* Helper function declarations go here */

#endif
