#include <stdio.h>

void testPrint();

void testPrint()
{
    printf("testPrint\n");
}