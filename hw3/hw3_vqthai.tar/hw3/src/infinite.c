
void infinite();

void infinite()
{
    while(1)
        ;
}