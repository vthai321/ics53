#include <stdio.h>
#include <stdlib.h>

int main()
{
	char i = 'A', j = 'Z';
	char *p  = &i;
    
    printf("Answer Question 1\n");
    
    i++;
    printf("Answer Question 2\n");
    
    return 0;
}
