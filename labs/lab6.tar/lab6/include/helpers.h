#ifndef HELPERS_H
#define HELPERS_H
#include <stdlib.h>
/* Helper function declarations go here */

void press_to_cont();

void null_check(void* ptr, long size);

void payload_check(void* ptr);

#endif
