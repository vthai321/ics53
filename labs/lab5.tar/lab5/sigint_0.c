#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>


int main()
{ 
    
    while(1){
	pause();
    }
    
    return 0;
}
