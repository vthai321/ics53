// Your name
// Netid



#include "hw0.h"

int main (int argc, char *argv[])
{

	//Comment/Delete this print statement and insert your hw0 code here 
	printf("Hello ICS53 student!\n"); 

	return 0;
}

//Function to print out a single arugment to the screen
void printArg(char * arg_str, int pos){

	//Insert your code here

	return;
}
