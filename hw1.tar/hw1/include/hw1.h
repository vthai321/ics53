// Useage statement
#define USAGE "usage:\n\
               53wgrep -n\n\
               53wgrep -l WORD [-I] [-S]\n\
               53wgrep -h WORD [-I] [-S] [-C FG BG]\n"

#include <stdio.h>
#include <stdlib.h>
#include "helpers1.h"
